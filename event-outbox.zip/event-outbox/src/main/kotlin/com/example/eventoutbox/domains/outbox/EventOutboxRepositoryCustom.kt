package com.example.eventoutbox.domains.outbox

interface EventOutboxRepositoryCustom {
    fun findNotPublishedEventsWithLimit(limit: Int): List<EventOutbox>
}
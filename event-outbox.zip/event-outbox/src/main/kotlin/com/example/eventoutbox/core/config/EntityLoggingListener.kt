package com.example.eventoutbox.core.config

import com.example.eventoutbox.domains.outbox.BaseEntity
import org.springframework.context.ApplicationListener
import org.springframework.data.mongodb.core.mapping.event.BeforeConvertEvent
import org.springframework.data.mongodb.core.mapping.event.MongoMappingEvent
import org.springframework.stereotype.Component

@Component
class EntityLoggingListener : ApplicationListener<MongoMappingEvent<*>> {

    override fun onApplicationEvent(event: MongoMappingEvent<*>) {
        if (event is BeforeConvertEvent<*>) {
            handleBeforeConvert(event)
        }
    }

    private fun handleBeforeConvert(event: BeforeConvertEvent<*>) {
        val source = event.source
        if (source is BaseEntity) {
            println("Before saving: createdAt = ${source.createdAt}, updatedAt = ${source.updatedAt}")
        }
    }
}
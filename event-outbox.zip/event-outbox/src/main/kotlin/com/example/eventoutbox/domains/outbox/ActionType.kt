package com.example.eventoutbox.domains.outbox

enum class ActionType {
    CREATE,
    READ,
    UPDATE,
    DELETE,
}

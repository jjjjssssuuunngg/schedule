package com.example.eventoutbox.domains.outbox

import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional

@Service
@Transactional(readOnly = true)
class EventOutboxService(
    private val eventOutboxRepository: EventOutboxRepository,
) {

    fun findNotPublishedEvents(): List<EventOutbox> {
        return eventOutboxRepository.findNotPublishedEvents()
    }
}
package com.example.eventoutbox.domains.outbox

import org.springframework.data.mongodb.core.mapping.Document
import java.time.LocalDateTime
import org.bson.types.ObjectId

@Document(collection = "event_outbox")
class EventOutbox(
    val officeNo: Long,
    val userNo: Long,
    val identifier: ObjectId,
    val identifierType: IdentifierType,
    val actionType: ActionType,
    val reason: String,
    val serverSource: String,
    version: Int = 1,
    published: Boolean = false,
    publishedAt: LocalDateTime? = null,

    override val id: ObjectId? = null,
    override var createdAt: LocalDateTime? = null,
    override var updatedAt: LocalDateTime? = null,
) : PublishableEntity(published, publishedAt) {

    var version = version
        private set

    companion object {
        fun createEvent(
            officeNo: Long,
            userNo: Long,
            identifier: ObjectId,
            identifierType: IdentifierType,
            actionType: ActionType,
            reason: String,
            serverSource: String,
        ): EventOutbox {
            return EventOutbox(
                officeNo = officeNo,
                userNo = userNo,
                identifier = identifier,
                identifierType = identifierType,
                actionType = actionType,
                reason = reason,
                serverSource = serverSource,
            )
        }

        fun createPublishedEvent(
            officeNo: Long,
            userNo: Long,
            identifier: ObjectId,
            identifierType: IdentifierType,
            actionType: ActionType,
            reason: String,
            serverSource: String,
        ): EventOutbox {
            return EventOutbox(
                officeNo = officeNo,
                userNo = userNo,
                identifier = identifier,
                identifierType = identifierType,
                actionType = actionType,
                reason = reason,
                serverSource = serverSource,
                published = true,
                publishedAt = LocalDateTime.now(),
            )
        }
    }
}
package com.example.eventoutbox.domains.outbox

import org.bson.types.ObjectId
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RestController

@RestController
class EventOutboxController(
    private val eventOutboxRepository: EventOutboxRepository,
) {

    @GetMapping("/event")
    fun getNotPublishedEvents(): EventOutbox {
        return eventOutboxRepository.save(
            EventOutbox.createEvent(
                officeNo = 123L,
                userNo = 1L,
                identifier = ObjectId.get(),
                identifierType = IdentifierType.APP,
                actionType = ActionType.CREATE,
                reason = "test reason",
                serverSource = "test source",
            )
        )
    }

}
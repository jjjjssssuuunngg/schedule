package com.example.eventoutbox.domains.outbox.scheduler

import org.springframework.beans.factory.annotation.Value
import org.springframework.scheduling.annotation.Scheduled
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional

@Service
@Transactional(readOnly = true)
class EventOutboxSchedulerService(
    private val tasks: List<ScheduledTask>,
) {

    @Scheduled(fixedRateString = "\${scheduler.fixed-rate}")
    fun runTask() {
        tasks.forEach { it.execute() }
    }

}
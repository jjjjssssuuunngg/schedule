package com.example.eventoutbox.domains.outbox

import org.springframework.data.domain.Sort
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.data.mongodb.core.query.Criteria
import org.springframework.data.mongodb.core.query.Query
import org.springframework.stereotype.Repository

@Repository
class EventOutboxRepositoryImpl(
    private val mongoTemplate: MongoTemplate,
) : EventOutboxRepositoryCustom {

    override fun findNotPublishedEventsWithLimit(limit: Int): List<EventOutbox> {
        val query = Query()
        query.addCriteria(Criteria.where("published").`is`(false))
        query.limit(limit)
            .with(Sort.by(Sort.Order.asc("createdAt")))
        return mongoTemplate.find(query, EventOutbox::class.java)
    }

}
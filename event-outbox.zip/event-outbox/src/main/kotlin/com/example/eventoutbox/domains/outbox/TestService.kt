package com.example.eventoutbox.domains.outbox

import org.bson.types.ObjectId
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional

@Service
@Transactional(readOnly = true)
class TestService(
    private val eventOutboxRepository: EventOutboxRepository,
) {

    @Transactional
    fun existLogic() {
        // 기존 로직..

        // 조건에 해당하면 이벤트 아웃박스 저장
        eventOutboxRepository.saveEvent(
            officeNo = 123L,
            userNo = 1L,
            identifier = ObjectId.get(),
            identifierType = IdentifierType.APP,
            actionType = ActionType.CREATE,
            reason = "test reason",
            serverSource = "test source",
        )
    }

}
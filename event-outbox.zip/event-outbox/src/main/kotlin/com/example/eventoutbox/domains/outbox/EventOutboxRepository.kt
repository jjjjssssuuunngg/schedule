package com.example.eventoutbox.domains.outbox

import org.bson.types.ObjectId
import org.springframework.data.mongodb.repository.MongoRepository
import org.springframework.data.mongodb.repository.Query

interface EventOutboxRepository : MongoRepository<EventOutbox, ObjectId>, EventOutboxRepositoryCustom {
    @Query("{ 'published': false }")
    fun findNotPublishedEvents(): List<EventOutbox>

    fun findByUserNo(userNo: Long): List<EventOutbox>

}

fun EventOutboxRepository.saveEvent(
    officeNo: Long,
    userNo: Long,
    identifier: ObjectId,
    identifierType: IdentifierType,
    actionType: ActionType,
    reason: String,
    serverSource: String,
) {
    val event = EventOutbox.createEvent(officeNo, userNo, identifier, identifierType, actionType, reason, serverSource)
    this.save(event)
}
package com.example.eventoutbox.domains.outbox.scheduler

import com.example.eventoutbox.core.config.LoggerDelegate
import com.example.eventoutbox.domains.outbox.EventOutboxRepository
import com.example.eventoutbox.domains.outbox.EventOutboxService

import org.springframework.stereotype.Component

@Component
class EventOutboxTask(
    private val eventOutboxRepository: EventOutboxRepository,
) : ScheduledTask {

    val logger by LoggerDelegate()

    override fun execute() {
        val events = eventOutboxRepository.findNotPublishedEventsWithLimit(10)

        if (events.isEmpty()) {
            logger.info("no events to publish")
            return
        }

        events.forEach { event ->
            logger.info("Read event: ${event.id} ${event.identifier} ${event.identifierType}")

            event.publish()
            eventOutboxRepository.save(event)
        }
    }
}
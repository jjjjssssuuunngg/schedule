package com.example.eventoutbox.domains.outbox

import org.bson.types.ObjectId
import java.time.LocalDateTime

abstract class PublishableEntity(
    published: Boolean = false,
    publishedAt: LocalDateTime? = null,
) : BaseEntity() {

    var published = published
        private set

    var publishedAt = publishedAt
        private set

    fun publish() {
        require(!published) { "Event is already published" }
        published = true
        publishedAt = LocalDateTime.now()
    }
}

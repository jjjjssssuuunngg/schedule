package com.example.eventoutbox.domains.outbox.scheduler

interface ScheduledTask {
    fun execute()
}
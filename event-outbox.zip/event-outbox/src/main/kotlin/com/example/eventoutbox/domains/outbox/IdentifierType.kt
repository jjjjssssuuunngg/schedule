package com.example.eventoutbox.domains.outbox

enum class IdentifierType {
    APP,
    APP_DATA,
    APP_DATA_FORM,
    COMPONENT_LINK_CONFIG
}
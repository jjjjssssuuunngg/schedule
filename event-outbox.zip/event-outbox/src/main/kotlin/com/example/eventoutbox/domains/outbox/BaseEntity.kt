package com.example.eventoutbox.domains.outbox

import org.bson.types.ObjectId
import org.springframework.data.annotation.CreatedBy
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.Id
import org.springframework.data.annotation.LastModifiedDate
import java.time.LocalDateTime

abstract class BaseEntity {
    @get:Id
    abstract val id: ObjectId?
    @get:CreatedDate
    abstract var createdAt: LocalDateTime?
    @get:LastModifiedDate
    abstract var updatedAt: LocalDateTime?
}
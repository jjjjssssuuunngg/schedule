package com.example.eventoutbox.core.config

import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.scheduling.TaskScheduler
import org.springframework.scheduling.annotation.EnableScheduling
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler

@Configuration
@EnableScheduling
class SchedulerConfig {

    val logger by LoggerDelegate()

    @Bean
    fun taskScheduler(): TaskScheduler {
        val scheduler = ThreadPoolTaskScheduler()
        scheduler.poolSize = 10
        scheduler.setThreadNamePrefix("event-outbox-scheduler-")
        scheduler.isRemoveOnCancelPolicy = true  // 취소된 작업의 스레드를 제거

        // 스케줄러 예외 핸들러
        scheduler.setErrorHandler {t: Throwable ->
            logger.error("Error occurred in scheduled task - " + t.message)
        }

        scheduler.setAwaitTerminationSeconds(60)    // 종료 시 대기 시간
        scheduler.setWaitForTasksToCompleteOnShutdown(true) // 종료 시 대기
        scheduler.initialize()

        return scheduler
    }

}
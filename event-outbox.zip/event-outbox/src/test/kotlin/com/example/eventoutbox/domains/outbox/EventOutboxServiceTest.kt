package com.example.eventoutbox.domains.outbox

import io.kotest.core.spec.style.BehaviorSpec
import io.kotest.matchers.shouldBe
import io.kotest.matchers.shouldNotBe
import org.bson.types.ObjectId
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class EventOutboxServiceTest(
    private val eventOutboxService: EventOutboxService,
    private val eventOutboxRepository: EventOutboxRepository,
) : BehaviorSpec ({

    beforeSpec {
        eventOutboxRepository.deleteAll()

        // 더미 데이터 100개 추가
        val dummyData = (1..100).map {
            EventOutbox.createEvent(
                officeNo = (100 + it).toLong(),
                userNo = it.toLong(),
                identifier = ObjectId.get(),
                identifierType = IdentifierType.values().random(),
                actionType = ActionType.values().random(),
                reason = "Dummy reason $it",
                serverSource = "Dummy source $it",
            )
        }

        eventOutboxRepository.saveAll(dummyData)
    }

    given("이벤트 아웃박스 조회 시") {
        When("조회가 정상적으로 요청된다면") {
            val result = eventOutboxService.findNotPublishedEvents()

            then("정상적으로 조회된다") {
                result shouldNotBe null
                result.size shouldBe 100
            }
        }
    }

})